# V38 Current Competition Status — 25 September 2026

## Finding
The project contains assets from two incompatible releases.

### Current Kaggle package supplied now
- train: 3292
- validation: 500
- test: 1000
- first test IDs: BICH_0003, BICH_0006, BICH_0007, BICH_0011

### Historical V38-aligned V2 probability assets
- validation probabilities: 500
- test probabilities: 1000
- first historical test IDs: BICH_0003, BICH_0006, BICH_0015, BICH_0016

### Cross-release overlap
- validation IDs in common: 55/500
- test IDs in common: 198/1000

Therefore the historical V38 submission/predictions cannot be used directly on the current Kaggle test set.

## What remains valid
V38 remains useful as:
- a protected historical champion artifact;
- a source of proven modeling ideas;
- a provenance reference for V35/V2/ensemble decisions.

It should not be relabeled as a current-package submission.

## Reproducibility blockers in historical V38
1. The exact fitted continuous implicit-toxicity meta-model artifact is missing.
2. The exact historical revision/weight hash of `aplycaebous/tb-XLM-R-fpt` was not pinned.
3. The current public page for that tb-XLM-R repository exposes no model card/license.

## Current-release action
Use only the current 3292/500/1000 package for current competition training/inference. Generate a fresh submission with the current test IDs and give it a new version number. Do not row-map historical V38 probabilities.

## Current attached file hashes
- train: 91f90c861a37a84f11f159af0956643212f77419e1419bb3431bce6fa9be0fa7
- validation: 7a5a2f8582a8edd4ae19e415a1f3e54b2618a7b889597af20f43499c21e34c08
- test: e9266e36b379e30576434090404338b4d1c77ad4ae68719a5c7d1a92baaceeee
- sample_submission: 382cd535b99becc6eb68e837f84f640a94030e9c636da471f439519b7ba97cc0
- historical V2 validation probabilities: 52d7d4f0555f501e14f51f30a013ea1df23277c3951cbb6cd907e5d093567a52
- historical V2 test probabilities: 12fe7e461faab5caab7778db73d45c00f7249623c25e4ce67a88a222e10f26e1
