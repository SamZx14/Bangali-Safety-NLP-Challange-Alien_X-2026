# Historical V38 System Description

V38 is a frozen historical ensemble/post-processing system, not a single model trained in one notebook.

## Recovered rules
- is_toxic: V14-style probability blended/ranked with V35 tb-XLM-R toxicity; top 673.
- implicit_toxicity: V14-style signal + train-only meta probability; top 70.
- sarcasm: V2 probability, threshold 0.175.
- contains_profanity: 0.95×V2 + 0.05×oldb snapshot 0; threshold 0.245.
- threatening: `nahidstaq/bge-m3-bangla` embeddings + five logistic regressions; top 32.
- identity_attack: 0.70×V2 + 0.30×oldb snapshot 2; threshold 0.3814.
- sexual_content: V2 probability, threshold 0.245.

## V35 neural component
- `aplycaebous/tb-XLM-R-fpt`
- 5 folds
- 3 epochs
- average epochs 2–3, then average folds
- length 128
- batch 4, accumulation 4
- backbone LR 1.2e-5
- head LR 2.5e-5
- weight decay 0.01
- warmup 0.10
- script/label-weighted sampling
- weighted multilabel BCE

## BGE component
- `nahidstaq/bge-m3-bangla`
- C=0.35
- liblinear
- positive sample weighting capped at 3

## Historical reproducibility limits
The exact fitted continuous implicit meta-model was not recovered and the exact historical tb-XLM-R revision was not pinned. Current licensing for the tb-XLM-R repository is unresolved.
